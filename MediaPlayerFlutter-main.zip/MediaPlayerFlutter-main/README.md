# Media Player Application Using Flutter

<a href="https://drive.google.com/file/d/1txAAzSuttKRp9P7bIYmH_epPf3PK3xEj/view?usp=sharing">
<img src="https://github.com/SalikSayyed/MediaPlayerFlutter/blob/main/github_assets/Capture.PNG" width="300"/>

<img src="https://github.com/SalikSayyed/MediaPlayerFlutter/blob/main/github_assets/Capture2.PNG" width="300"/>
</a>

## Media Player application in Flutter
