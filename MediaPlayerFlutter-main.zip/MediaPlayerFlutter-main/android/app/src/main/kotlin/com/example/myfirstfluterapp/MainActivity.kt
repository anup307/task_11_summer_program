package com.example.myfirstfluterapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
